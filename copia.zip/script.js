// let element = document.querySelector("textarea");

// element.addEventListener("click", function (event) {
//   event.target.style.borderColor = "red";
// });
